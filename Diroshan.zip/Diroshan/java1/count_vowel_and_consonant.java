package java1;

public class count_vowel_and_consonant {

	public static void main(String[] args) {
		
		String sentence;
		
		int vowelCount;
		int consonantCount;
		vowelCount = 0;
		consonantCount =0;
		
		sentence ="ALPHABET";
		char[] ch=new char[sentence.length()];
		
		
		
		for(int i=0;i<sentence.length();i++) 
		{
			ch[i] = sentence.charAt(i);
		}
		
for(int i=0;i<sentence.length();i++)
	{
	
			if(ch[i]=='A' || ch[i]=='a'|| ch[i]=='E' ||ch[i]=='e' || ch[i]=='I' ||  ch[i]=='i' || ch[i]=='O'|| ch[i]=='o' ||ch[i]=='U'|| ch[i]=='u')
			{
				vowelCount=vowelCount + 1;
			}
			else
			{
				
				consonantCount=consonantCount+1;
				
			}
			
	}
		System.out.println("No of Vowels : " + vowelCount + " & consonants : " + consonantCount);
		

	
	}
	
}
