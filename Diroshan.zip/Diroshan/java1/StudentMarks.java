package java1;

import java.util.Arrays;
import java.util.Scanner;

public class StudentMarks {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numStudents = 2;
        int numSubjects = 3;

       
        int[][] marks = new int[numStudents][numSubjects];
        int[][] marks1 = new int[numStudents][numSubjects];

      
        for (int i = 0; i < numStudents; i++)
        {
            System.out.println("Enter marks for student " + (i+1) + ":");
            for (int j = 0; j < numSubjects; j++)
            {
                System.out.print("Enter marks for subject " + (j+1) + ": ");
                marks[i][j] = scanner.nextInt();
            }
        }
        for (int i = 0; i < numStudents; i++)
        {
            
            for (int j = 0; j < numSubjects; j++)
            {
                
                marks1[i][j] = scanner.nextInt();
            }
        }

       
        System.out.println("Student Marks:");
        for (int i = 0; i < numStudents; i++)
        {
            System.out.print("Student " + (i+1) + ": ");
            for (int j = 0; j < numSubjects; j++) 
            {
                System.out.print(marks[i][j] + " ");
            }
            System.out.println();
        }
        int sum=0;
        
        for(int i=0;i<2;i++)
        {
        	for(int j=0;j<3;j++)
        	{
        		sum=sum+marks[i][j];
        		
        		
        	}
        	
        	System.out.println("Total marks of student "+(i+1)+" :" +sum); 
        }
        
        for(int i=0;i<2;i++)
    {
        	for(int j=0;j<3;j++)
        {
        		
        		Arrays.sort(marks1);
        }
        	System.out.println( marks1);
    }
        
    
        
    }
}
