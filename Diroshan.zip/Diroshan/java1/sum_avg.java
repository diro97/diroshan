package java1;

public class sum_avg {

	public static void main(String[] args) {
		 int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

	       
	        double sum = 0;
	        for (int number : numbers) {
	            sum += number;
	        }
	        double average = sum / numbers.length;

	        System.out.println("The average of the 10 numbers is: " + average);

	}

}
