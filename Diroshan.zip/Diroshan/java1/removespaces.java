package java1;

public class removespaces {

	public static void main(String[] args) {
		
		String str = "  Hello  World!  ";
        String strWithoutSpaces = str.replaceAll("\\s", "");
        System.out.println("Original string: " + str);
        System.out.println("String without spaces: " + strWithoutSpaces);

	}

}
