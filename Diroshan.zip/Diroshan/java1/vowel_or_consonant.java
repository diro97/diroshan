package java1;

import java.util.Scanner;

public class vowel_or_consonant {

	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the alphabet");
		
		char m = scan.next().charAt(0);
		
		if(m=='A' || m=='a'|| m=='E' || m=='e' || m=='I' ||  m=='i' || m=='O'|| m=='o' ||m=='U'|| m=='u')
		{
			System.out.println(m + " is vowel letter");
		}
		else
		{
			System.out.println(m + " is consonant");
		}

	}

}
