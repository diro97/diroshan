package java1;

public class Q21 {
    public static void main(String[] args) {
        
        String[][] graph = new String[400][400];

        
        for (int i = 0; i < graph.length; i++) {
            for (int j = 0; j < graph[0].length; j++) {
                graph[i][j] = " ";
            }
        }

        
        for (int i = 0; i < graph.length; i++) {
            graph[200][i] = "-";
            graph[i][200] = "|";
        }

        
        graph[200][200] = "+";

       
        double m = 1.5;
        double c = 10.0;

        
        for (int x = -50; x <= 50; x++) {
            int y = (int) (m * x + c);

           
            if (y >= 0 && y < graph.length) {
                graph[200 - y][200 + x] = "*";
            }
        }

        
        for (int i = 0; i < graph.length; i++) {
            for (int j = 0; j < graph[0].length; j++) {
                System.out.print(graph[i][j]);
            }
            System.out.println();
        }
    }
}
