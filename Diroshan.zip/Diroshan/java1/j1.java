package java1;

import java.util.Scanner;

public class j1 {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		int[] arr=new int[6];
		
		
		Scanner scan=new Scanner(System.in);
		
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=scan.nextInt();
			
		}
		
		
		
		
		
		
		System.out.println();
		
		
		
		for (int i=0;i<arr.length;i++) {
			
			if(arr[i]>0) {
				
				System.out.println(arr[i]+  " ");
			}
		}
			
			for (int i=0;i<arr.length;i++) {
				
				if(arr[i]<0) {
					
					System.out.println(arr[i]+  " ");
				}
		}
		
	}

}
