package java1;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		
	     Scanner scan = new Scanner(System.in);
	     
	        System.out.print("enter the number of Fibonacci numbers to print: ");
	        
	        int m = scan.nextInt();

	        int num1 = 1, num2 = 1;
	        int i = 2;

	        
	        System.out.print(num1 + " " + num2 + " ");

	        
	        do
	        {
	            int fib = num1 + num2;
	            System.out.print(fib + " ");
	            num1 = num2;
	            num2 = fib;
	            i++;
	        } 
	        while (i < m);

	       
	    }
	}


