package java1;

import java.util.Arrays;

public class Sort_Elements_Dictionary_Order {

	public static void main(String[] args) {
		
       
        String names[] = { "Ajith", "Vijay", "Rajni", "Kamal" };
           
       
        Arrays.sort(names);
       
        System.out.println( "The names in alphabetical order are: ");
           
        for (int i = 0; i < 4; i++) 
        {
            System.out.println(names[i]);
        }
    }

	}


