package java1;

import java.util.Scanner;

public class find_factor {

	public static void main(String[] args) {
		
		Scanner scan= new Scanner(System.in);
		System.out.println("Enter tne number");
		int m=scan.nextInt();
		
		System.out.print("Factors of " + m + " are : ");
		for(int i=1;i<=m;i++)
		{
			if(m%i==0)
			{
				System.out.print(" "+i);
				
			}
			
		}

	}

}
 