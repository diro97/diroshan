package java1;

import java.util.Scanner;

public class Multiplications_Table2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 System.out.println("entet the number ");
			Scanner scan= new Scanner(System.in);
			
			int m=scan.nextInt();
			
			int i = 0;
			while(i<11)
			{
				System.out.println(m + "*" + i + "=" + m*i);
				i++;
			}
	}

}
