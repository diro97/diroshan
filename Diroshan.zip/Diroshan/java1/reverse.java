package java1;

public class reverse {

	public static void main(String[] args) {
		
		int num = 12345;
        int revNum = 0;

        while (num > 0) {
            int digit = num % 10;
            revNum = revNum * 10 + digit;
            num /= 10;
        }

        System.out.println("The reversed number is: " + revNum);
	

	}

}
