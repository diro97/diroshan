package java1;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
        System.out.print("Enter the value of m ");
        int m = scan.nextInt();
        int factorial = 1;
        
        for (int i = 1; i <= m; i++) 
        
        {
          
           
            
                factorial =factorial * i;
            }
        
            System.out.println( "factorial of "+ m + " is " + factorial);
        
    
	}

}
