package java1;

public class Q20_matrix {
    public static void main(String[] args) {
       
        int[][] matrix = {{1, 2, 3, 4, 5},
                          {6, 7, 8, 9, 10},
                          {11, 12, 13, 14, 15},
                          {16, 17, 18, 19, 20},
                          {21, 22, 23, 24, 25}};

        
        for (int i = 1; i < 5; i++) {
            matrix[i][0] = 0;
        }
        matrix[4][1] = 0;

        
        System.out.println("Original matrix:");
        printMatrix(matrix);

        
        int[][] rotatedMatrix = rotateMatrix(matrix);

       
        System.out.println("Rotated matrix:");
        printMatrix(rotatedMatrix);
    }

    
    public static void printMatrix(int[][] matrix) {
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }

   
    public static int[][] rotateMatrix(int[][] matrix) {
        int rows = matrix.length;
        int cols = matrix[0].length;
        int[][] rotatedMatrix = new int[cols][rows];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                rotatedMatrix[j][rows - i - 1] = matrix[i][j];
            }
        }

        return rotatedMatrix;
    }
}
