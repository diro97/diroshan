package java1;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class two_time_intervals {

	public static void main(String[] args) {
		 
			  
		        
		        LocalTime time1 = LocalTime.of(18, 00, 00);
		        LocalTime time2 = LocalTime.of(20, 22, 00);
		  
		   
		        long hours = ChronoUnit.HOURS.between(time1, time2);
		  
		       
		        long minutes= ChronoUnit.MINUTES.between(time1, time2) % 60;
		            
		  
		     
		        long seconds= ChronoUnit.SECONDS.between(time1, time2) % 60;
		            
		  
		        
		        System.out.println("Difference is " + hours + " hours " + minutes  + " minutes " + seconds + " seconds.");
			           
		            
		    

	}

}
