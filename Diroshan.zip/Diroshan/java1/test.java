package java1;



	class animal

{
	static void  sound()
		{// TODO Auto-generated method stub
		System.out.println("hello animal");
		}
}
		
		class dog extends animal
			{
			
			static void sound() 
			{
				
				System.out.print("hello dog");
			}
		}
		public class test {
		public static void main(String[] args)
		{
			animal b= new animal();
			b.sound();
			
			dog a=new dog();
			a.sound();
			
		}
}


