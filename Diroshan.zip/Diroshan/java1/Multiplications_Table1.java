package java1;

import java.util.Scanner;

public class Multiplications_Table1 {

	public static void main(String[] args) {
		
		
		 System.out.println("entet the number ");
		Scanner scan= new Scanner(System.in);
		
		int m=scan.nextInt();
		
		
		for(int i=1;i<11;i++)
		{
			
			System.out.println(m + "*" + i + "=" + m*i);
			
		}
	}

}
 