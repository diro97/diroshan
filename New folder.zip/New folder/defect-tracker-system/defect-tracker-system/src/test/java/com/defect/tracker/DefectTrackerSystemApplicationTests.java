package com.defect.tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DefectTrackerSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
