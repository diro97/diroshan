package com.defect.tracker.service;

public interface ProjectStatusService {

}
