package com.defect.tracker.service;

public interface SeverityService {

}
