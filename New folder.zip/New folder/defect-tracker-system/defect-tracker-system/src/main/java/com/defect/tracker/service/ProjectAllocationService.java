package com.defect.tracker.service;

public interface ProjectAllocationService {

}
