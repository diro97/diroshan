package com.defect.tracker.resquest.dto;

public class ModuleRequest {

}
