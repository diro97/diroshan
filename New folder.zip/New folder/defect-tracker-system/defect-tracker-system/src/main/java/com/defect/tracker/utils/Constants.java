package com.defect.tracker.utils;

public class Constants {
  public static final String DESIGNATION = "designation";
  public static final String DESIGNATIONS = "designations";
  public static final String DEFECTSTATUS = "defectstatus";
  public static final String DEFECTSTATUSES = "defectstatuses";
  public static final String RELEASE = "release";
  public static final String RELEASES = "releases";
}
