package com.defect.tracker.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.defect.tracker.repositories.DefectRepository;
import com.defect.tracker.service.DefectService;

@Service
public class DefectServiceImpl implements DefectService {
  @Autowired
  private DefectRepository defectRepository;

  @Override
  public boolean existsByDefectStatus(Long statusId) {
    return defectRepository.existsByStatusId(statusId);
  }
}
