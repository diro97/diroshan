package com.defect.tracker.service;

public interface DefectService {
  public boolean existsByDefectStatus(Long statusId);
}
