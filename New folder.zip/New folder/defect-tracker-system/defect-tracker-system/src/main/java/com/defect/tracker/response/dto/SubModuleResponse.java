package com.defect.tracker.response.dto;

public class SubModuleResponse {

}
