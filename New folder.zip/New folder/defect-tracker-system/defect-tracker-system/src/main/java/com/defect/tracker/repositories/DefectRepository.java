package com.defect.tracker.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import com.defect.tracker.entities.Defect;

public interface DefectRepository extends JpaRepository<Defect, String> {
  boolean existsByStatusId(Long statusId);
}
