package com.defect.tracker.resquest.dto;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import com.defect.tracker.entities.ProjectStatus;
import com.defect.tracker.entities.ProjectType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProjectRequest {
  
  private Long id;
  private String projectName;
  private String prefix;
  private String startDate;
  private String endDate;
  @ManyToOne
  @JoinColumn(name = "projectTypeId", nullable = false)
  private ProjectType type;
  @ManyToOne
  @JoinColumn(name = "projectStatusId", nullable = false)
  private ProjectStatus status;
  private String describtion;

}
