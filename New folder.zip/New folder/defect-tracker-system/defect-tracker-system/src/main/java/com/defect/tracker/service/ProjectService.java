package com.defect.tracker.service;

import java.util.List;
import com.defect.tracker.response.dto.ProjectResponse;
import com.defect.tracker.resquest.dto.ProjectRequest;

public interface ProjectService { 
 public void saveProject(ProjectRequest projectRequest);
 
 public List<ProjectResponse> getAllProject();
 
 public boolean isProjectExistByprojectName(String projectName);
 
 public boolean isProjectExistsByprefix(String prefix);
 
 public ProjectResponse getProjectById(Long id);
 
 public boolean existsByprojectStatus(Long id);
 
 public boolean isUpdatedProjectStatus()
 

}
