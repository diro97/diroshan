package com.defect.tracker.service.impl;

public class SeverityServiceImpl {

}
