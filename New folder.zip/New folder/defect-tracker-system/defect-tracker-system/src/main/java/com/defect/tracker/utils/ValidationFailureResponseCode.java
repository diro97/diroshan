package com.defect.tracker.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import lombok.Getter;
import lombok.Setter;

@Component
@PropertySource("classpath:MessagesAndCodes.properties")
@Getter
@Setter
public class ValidationFailureResponseCode {
  // Common Success code
  @Value("${code.success.common}")
  private String commonSuccessCode;
  @Value("${code.failure.common}")
  private String failureCode;
  // Validation code for Designation
  @Value("${code.validation.designation.alreadyExists}")
  private String designationAlreadyExists;
  @Value("${code.validation.designation.notExists}")
  private String designationNotExistsCode;

  // Validation code for Defect-Status
  @Value("${code.validation.defectstatus.alreadyExists}")
  private String defectstatusAlreadyExists;
  
  @Value("${code.validation.defectstatus.notExists}")
  private String defectstatusNotExistscode;
  
  @Value("${code.validation.defectstatus.canNotDelete}")
  private String defectstatuscanNotDeleteCode;

  // Messages for Designation
  @Value("${message.success.save.designation}")
  private String saveDesignationSuccessMessage;
  @Value("${message.validation.designation.alreadyExists}")
  private String validationDesignationAlreadyExists;
  @Value("${message.success.getAll.designation}")
  private String getAllDesignationSuccessMessage;
  @Value("${message.validation.designation.notExists}")
  private String designationNotExistsMessage;
  @Value("${message.success.getById.designation}")
  private String getDesignationByIdSuccessMessage;
  @Value("${message.success.update.designation}")
  private String updateDesignationSuccessMessage;
  @Value("${message.success.delete.designation}")
  private String deleteDesignationSuccessMessage;
  
  // Messages for DefectStatus
  
  @Value("${message.success.save.defectstatus}")
  private String saveDefectStatusSuccessMessage;
  @Value("${message.validation.defectstatus.alreadyExists}")
  private String validationDefectStatusAlreadyExists;
  @Value("${message.success.getAll.defectstatus}")
  private String getAllDefectStatusSuccessMessage;
  @Value("${message.validation.defectstatus.notExists}")
  private String defectstatusNotExistsMessage;
  @Value("${message.success.getById.defectstatus}")
  private String getDefectStatusByIdSuccessMessage;

  @Value("${message.success.update.defectstatus}")
  private String updateDefectStatusSuccessMessage;

  @Value("${message.success.delete.defectstatus}")
  private String deleteDefectStatusSuccessMessage;

  @Value("${message.validation.defectstatus.canNotDelete}")
  private String DefectStatusCanNotDeleteMessage;

  // Validation code for Release
  @Value("${code.validation.release.alreadyExists}")
  private String releaseAlreadyExists;
  @Value("${code.validation.release.notExists}")
  private String releaseNotExistsCode;
  // Messages for Release
  @Value("${message.success.save.release}")
  private String saveReleaseSuccessMessage;
  @Value("${message.validation.release.alreadyExists}")
  private String validationReleaseAlreadyExists;
  @Value("${message.success.getAll.release}")
  private String getAllReleaseSuccessMessage;
  @Value("${message.validation.release.notExists}")
  private String releaseNotExistsMessage;
  @Value("${message.success.getById.release}")
  private String getReleaseByIdSuccessMessage;
  @Value("${message.success.update.release}")
  private String updateReleaseSuccessMessage;
  @Value("${message.success.delete.release}")
  private String deleteReleaseSuccessMessage;
}
